﻿namespace AuthServer
{
    public static class Secret
    {
        public static string Key = "gandasomuch";
    }
}